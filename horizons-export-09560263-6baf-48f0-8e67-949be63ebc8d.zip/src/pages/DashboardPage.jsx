import React, { useState, useEffect } from 'react';
import { Coins, Zap, Clock, Users, Settings, ListChecks, Gamepad2, Loader2 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useMining } from '@/contexts/MiningContext';
import { useToast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/supabaseClient';

import StatCard from '@/components/dashboard/StatCard';
import InfoCard from '@/components/dashboard/InfoCard';
import LeaderboardCard from '@/components/dashboard/LeaderboardCard';
import MiningWalletCard from '@/components/dashboard/MiningWalletCard';
import WithdrawDialog from '@/components/dashboard/WithdrawDialog';

const DashboardPage = () => {
  const { user, loading: authLoading } = useAuth();
  const { miningData, claimFreeTokens, withdrawTokens, loading: miningContextLoading, fetchMiningData } = useMining();
  const { toast } = useToast();

  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawAddress, setWithdrawAddress] = useState('');
  const [withdrawNetwork, setWithdrawNetwork] = useState('Solana');
  const [isWithdrawDialogOpen, setIsWithdrawDialogOpen] = useState(false);
  const [leaderboardData, setLeaderboardData] = useState([]);
  const [leaderboardLoading, setLeaderboardLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);

  useEffect(() => {
    const fetchLeaderboard = async () => {
      setLeaderboardLoading(true);
      const { data, error } = await supabase
        .from('mining_data')
        .select('user_id, balance, profiles ( username )')
        .order('balance', { ascending: false })
        .limit(10);

      if (error) {
        console.error("Error fetching leaderboard:", error);
        toast({ title: "خطأ", description: "لم يتم تحميل لوحة الشرف.", variant: "destructive" });
      } else {
        const formattedLeaderboard = data.map((entry, index) => ({
          rank: index + 1,
          name: entry.profiles?.username || `User-${entry.user_id.substring(0,6)}`,
          amount: entry.balance,
        }));
        setLeaderboardData(formattedLeaderboard);
      }
      setLeaderboardLoading(false);
    };

    if (user) {
        fetchLeaderboard();
    }
  }, [user, toast]);


  const handleClaim = async () => {
    setActionLoading(true);
    const result = await claimFreeTokens();
    if (result.success) {
      toast({
        title: "تم بنجاح!",
        description: `لقد طالبت بـ ${result.amount.toFixed(18)} MEMZ.`,
        variant: "default",
      });
    } else {
      toast({
        title: "انتظر قليلاً",
        description: result.message,
        variant: "destructive",
      });
    }
    setActionLoading(false);
  };
  
  const handleWithdraw = async () => {
    setActionLoading(true);
    if (!withdrawAmount || !withdrawAddress || !withdrawNetwork) {
      toast({ title: "خطأ", description: "يرجى ملء جميع حقول السحب.", variant: "destructive" });
      setActionLoading(false);
      return;
    }
    const amount = parseFloat(withdrawAmount);
    if (isNaN(amount) || amount <= 0) {
      toast({ title: "خطأ", description: "مبلغ السحب غير صالح.", variant: "destructive" });
      setActionLoading(false);
      return;
    }
    if (amount < miningData.minWithdrawalAmount) {
        toast({ title: "خطأ", description: `الحد الأدنى للسحب هو ${miningData.minWithdrawalAmount} MEMZ.`, variant: "destructive" });
        setActionLoading(false);
        return;
    }

    const result = await withdrawTokens(amount, withdrawAddress, withdrawNetwork);
    if (result.success) {
      toast({
        title: "طلب سحب ناجح",
        description: result.message,
        variant: "default",
      });
      setIsWithdrawDialogOpen(false);
      setWithdrawAmount('');
      setWithdrawAddress('');
    } else {
      toast({
        title: "فشل السحب",
        description: result.message,
        variant: "destructive",
      });
    }
    setActionLoading(false);
  };
  
  const isLoading = authLoading || miningContextLoading || actionLoading;

  if (authLoading && !user) { 
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-900 text-white">
        <Loader2 className="h-12 w-12 animate-spin text-purple-500" />
      </div>
    );
  }


  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6 sm:space-y-8"
    >
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 sm:gap-4">
        <h1 className="text-3xl sm:text-4xl font-bold text-gray-100">لوحة التحكم</h1>
        <span className="text-xs sm:text-sm text-gray-400">مرحبًا بك، <span className="font-semibold text-purple-400">{user?.username || user?.email}</span>!</span>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-6">
        <StatCard icon={Coins} title="رصيدك الحالي" value={`${parseFloat(miningData.balance || 0).toFixed(6)} MEMZ`} color="text-yellow-300" size="small"/>
        <StatCard icon={Zap} title="سرعة التعدين" value={`${parseFloat(miningData.mining_rate || 0).toFixed(4)} MEMZ/س`} color="text-blue-400" size="small"/>
        <StatCard icon={Clock} title="المطالبة التالية" value={miningData.can_claim ? "جاهز!" : (miningData.next_claim_time ? new Date(miningData.next_claim_time).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit'}) : '...') } color={miningData.can_claim ? "text-green-400" : "text-orange-400"} size="small"/>
        <StatCard icon={Users} title="الإحالات" value={`${miningData.referrals || 0}`} color="text-teal-400" size="small"/>
      </div>
      
      <div className="grid lg:grid-cols-3 gap-4 sm:gap-6">
        <MiningWalletCard 
          miningData={miningData} 
          onClaim={handleClaim} 
          onWithdrawOpen={() => setIsWithdrawDialogOpen(true)} 
          loading={isLoading}
        />
        <LeaderboardCard leaderboardData={leaderboardData} loading={leaderboardLoading} />
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-6">
        <InfoCard title="نظام الإحالات" description="شارك رابطك واكسب MEMZ عن كل صديق." icon={Users} link="/profile#referrals" linkText="الإحالات" />
        <InfoCard title="المهام اليومية" description="أكمل المهام لربح المزيد من التوكنات." icon={ListChecks} link="/tasks" linkText="عرض المهام" />
        <InfoCard title="العب واربح" description="العب MEMEZAK Clicker واكسب توكنات." icon={Gamepad2} link="/game" linkText="إلعب الآن" />
        <InfoCard title="إعدادات الحساب" description="حدث معلوماتك وأمان حسابك." icon={Settings} link="/profile#settings" linkText="الإعدادات" />
      </div>

      <WithdrawDialog
        isOpen={isWithdrawDialogOpen}
        onOpenChange={setIsWithdrawDialogOpen}
        withdrawAmount={withdrawAmount}
        setWithdrawAmount={setWithdrawAmount}
        withdrawAddress={withdrawAddress}
        setWithdrawAddress={setWithdrawAddress}
        withdrawNetwork={withdrawNetwork}
        setWithdrawNetwork={setWithdrawNetwork}
        handleWithdraw={handleWithdraw}
        minWithdrawalAmount={miningData.minWithdrawalAmount}
        isLoading={isLoading}
      />
    </motion.div>
  );
};

export default DashboardPage;