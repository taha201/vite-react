import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useMining } from '@/contexts/MiningContext';
import { supabase } from '@/lib/supabaseClient';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';
import { User, Settings, Shield, Gift, List, Copy, Loader2 } from 'lucide-react';

const ProfilePage = () => {
  const { user, updateUser, loading: authLoading } = useAuth();
  const { miningData, loading: miningLoading } = useMining();
  const { toast } = useToast();

  const [username, setUsername] = useState(user?.username || '');
  const [email, setEmail] = useState(user?.email || '');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [referralLink, setReferralLink] = useState('');
  const [transactions, setTransactions] = useState([]);
  const [pageLoading, setPageLoading] = useState(false);

  useEffect(() => {
    if (user) {
      setUsername(user.username || '');
      setEmail(user.email || '');
      setReferralLink(`${window.location.origin}/auth?ref=${user.id}`);
      
      const fetchTransactions = async () => {
        setPageLoading(true);
        const { data, error } = await supabase
          .from('transaction_history')
          .select('*')
          .eq('user_id', user.id)
          .order('date', { ascending: false })
          .limit(50);
        if (error) {
          console.error("Error fetching transactions:", error);
          toast({ title: "خطأ", description: "لم يتم تحميل سجل المعاملات.", variant: "destructive" });
        } else {
          setTransactions(data);
        }
        setPageLoading(false);
      };
      fetchTransactions();
    }
  }, [user, toast]);

  const handleProfileUpdate = async (e) => {
    e.preventDefault();
    setPageLoading(true);
    if (!user) return;

    const updates = {};
    if (username !== user.username) updates.username = username;
    // Email update requires Supabase email change flow, more complex
    // For now, we'll just update it in profiles table if it's different
    if (email !== user.email) updates.email = email;


    if (Object.keys(updates).length > 0) {
        await updateUser(updates); // updateUser in AuthContext handles Supabase update
    }
    setPageLoading(false);
  };

  const handlePasswordChange = async (e) => {
    e.preventDefault();
    setPageLoading(true);
    if (newPassword !== confirmNewPassword) {
      toast({ title: "خطأ", description: "كلمتا المرور الجديدتان غير متطابقتين.", variant: "destructive" });
      setPageLoading(false);
      return;
    }
    if (newPassword.length < 6) {
      toast({ title: "خطأ", description: "يجب أن تكون كلمة المرور الجديدة 6 أحرف على الأقل.", variant: "destructive" });
      setPageLoading(false);
      return;
    }

    const { error } = await supabase.auth.updateUser({ password: newPassword });

    if (error) {
      toast({ title: "خطأ في تغيير كلمة المرور", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "تم بنجاح", description: "تم تغيير كلمة المرور بنجاح." });
      setCurrentPassword('');
      setNewPassword('');
      setConfirmNewPassword('');
    }
    setPageLoading(false);
  };

  const copyReferralLink = () => {
    navigator.clipboard.writeText(referralLink);
    toast({ title: "تم النسخ!", description: "تم نسخ رابط الإحالة إلى الحافظة." });
  };

  if (authLoading || miningLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-900 text-white">
        <Loader2 className="h-12 w-12 animate-spin text-purple-500" />
      </div>
    );
  }
  
  if (!user) {
    return (
      <div className="text-center py-10">
        <p className="text-xl text-gray-300">يرجى تسجيل الدخول لعرض ملفك الشخصي.</p>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="max-w-4xl mx-auto space-y-8"
    >
      <h1 className="text-4xl font-bold text-gray-100 text-center">الملف الشخصي</h1>

      <Tabs defaultValue="profile" className="w-full">
        <TabsList className="grid w-full grid-cols-4 bg-gray-800/60 p-2 rounded-lg">
          <TabsTrigger value="profile" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white"><User className="inline-block mr-2 h-5 w-5" />الملف الشخصي</TabsTrigger>
          <TabsTrigger value="security" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white"><Shield className="inline-block mr-2 h-5 w-5" />الأمان</TabsTrigger>
          <TabsTrigger value="referrals" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white"><Gift className="inline-block mr-2 h-5 w-5" />الإحالات</TabsTrigger>
          <TabsTrigger value="transactions" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white"><List className="inline-block mr-2 h-5 w-5" />المعاملات</TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="mt-6">
          <Card className="bg-gray-800/70 border-purple-500/40">
            <CardHeader>
              <CardTitle className="text-2xl text-gray-100">معلومات الحساب</CardTitle>
              <CardDescription className="text-gray-400">قم بتحديث معلومات حسابك هنا.</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleProfileUpdate} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="username-profile" className="text-gray-300">اسم المستخدم</Label>
                  <Input id="username-profile" value={username} onChange={(e) => setUsername(e.target.value)} className="bg-gray-900/50 border-gray-700 focus:border-purple-500" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email-profile" className="text-gray-300">البريد الإلكتروني</Label>
                  <Input id="email-profile" type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="bg-gray-900/50 border-gray-700 focus:border-purple-500" disabled />
                  <p className="text-xs text-gray-500">لتغيير البريد الإلكتروني، يرجى التواصل مع الدعم.</p>
                </div>
                <Button type="submit" className="bg-purple-600 hover:bg-purple-700" disabled={pageLoading}>
                  {pageLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  حفظ التغييرات
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="mt-6">
          <Card className="bg-gray-800/70 border-purple-500/40">
            <CardHeader>
              <CardTitle className="text-2xl text-gray-100">تغيير كلمة المرور</CardTitle>
              <CardDescription className="text-gray-400">قم بتحديث كلمة المرور الخاصة بك بانتظام للحفاظ على أمان حسابك.</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handlePasswordChange} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="newPassword">كلمة المرور الجديدة</Label>
                  <Input id="newPassword" type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required className="bg-gray-900/50 border-gray-700 focus:border-purple-500" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="confirmNewPassword">تأكيد كلمة المرور الجديدة</Label>
                  <Input id="confirmNewPassword" type="password" value={confirmNewPassword} onChange={(e) => setConfirmNewPassword(e.target.value)} required className="bg-gray-900/50 border-gray-700 focus:border-purple-500" />
                </div>
                <Button type="submit" className="bg-purple-600 hover:bg-purple-700" disabled={pageLoading}>
                  {pageLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  تغيير كلمة المرور
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="referrals" className="mt-6" id="referrals">
          <Card className="bg-gray-800/70 border-purple-500/40">
            <CardHeader>
              <CardTitle className="text-2xl text-gray-100">نظام الإحالات</CardTitle>
              <CardDescription className="text-gray-400">شارك رابط الإحالة الخاص بك واكسب MEMZ عن كل صديق ينضم ويبدأ التعدين!</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label htmlFor="referralLink" className="text-gray-300">رابط الإحالة الخاص بك</Label>
                <div className="flex items-center space-x-2 rtl:space-x-reverse mt-1">
                  <Input id="referralLink" value={referralLink} readOnly className="bg-gray-900/50 border-gray-700" />
                  <Button variant="outline" size="icon" onClick={copyReferralLink} className="border-purple-500 text-purple-400 hover:bg-purple-500/20">
                    <Copy className="h-5 w-5" />
                  </Button>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-center">
                <div className="p-4 bg-gray-900/50 rounded-lg">
                  <p className="text-gray-400 text-sm">عدد الإحالات</p>
                  <p className="text-2xl font-bold text-purple-400">{miningData.referrals || 0}</p>
                </div>
                <div className="p-4 bg-gray-900/50 rounded-lg">
                  <p className="text-gray-400 text-sm">إجمالي أرباح الإحالات</p>
                  <p className="text-2xl font-bold text-yellow-400">{(miningData.total_referral_earnings || 0).toFixed(6)} MEMZ</p>
                </div>
              </div>
              <p className="text-xs text-gray-500">مكافأة التسجيل عبر رابطك: {miningData.referralBonus} MEMZ. مكافأتك عن كل إحالة: {miningData.referralBonus / 2} MEMZ.</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="transactions" className="mt-6" id="transactions">
          <Card className="bg-gray-800/70 border-purple-500/40">
            <CardHeader>
              <CardTitle className="text-2xl text-gray-100">سجل المعاملات</CardTitle>
              <CardDescription className="text-gray-400">عرض أحدث معاملاتك.</CardDescription>
            </CardHeader>
            <CardContent>
              {pageLoading && <div className="flex justify-center py-4"><Loader2 className="h-8 w-8 animate-spin text-purple-500" /></div>}
              {!pageLoading && transactions.length === 0 && <p className="text-gray-400 text-center py-4">لا يوجد معاملات لعرضها.</p>}
              {!pageLoading && transactions.length > 0 && (
                <ul className="space-y-3 max-h-96 overflow-y-auto">
                  {transactions.map(tx => (
                    <li key={tx.id} className="p-4 bg-gray-900/50 rounded-lg flex justify-between items-center text-sm">
                      <div>
                        <p className={`font-semibold ${tx.amount > 0 ? 'text-green-400' : 'text-red-400'}`}>
                          {tx.type === 'claim' ? 'مطالبة' : tx.type === 'upgrade' ? 'ترقية باقة' : tx.type === 'reward' ? 'مكافأة' : tx.type === 'task_reward' ? 'مكافأة مهمة' : tx.type === 'referral_bonus' ? 'مكافأة إحالة' : tx.type === 'withdraw_request' ? 'طلب سحب' : 'غير معروف'}
                        </p>
                        <p className="text-xs text-gray-500">{tx.description || new Date(tx.date).toLocaleDateString('ar-EG')}</p>
                      </div>
                      <div className="text-right">
                        <p className={`font-bold ${tx.amount > 0 ? 'text-green-400' : 'text-red-400'}`}>{tx.amount > 0 ? '+' : ''}{parseFloat(tx.amount).toFixed(6)} MEMZ</p>
                        <p className="text-xs text-gray-500">{new Date(tx.date).toLocaleString('ar-EG')}</p>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </motion.div>
  );
};

export default ProfilePage;