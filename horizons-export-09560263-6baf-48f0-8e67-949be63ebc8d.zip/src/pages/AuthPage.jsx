import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';
import { LogIn, UserPlus, Loader2, MailCheck } from 'lucide-react';

const AuthPage = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [pageLoading, setPageLoading] = useState(false);
  const [showConfirmationMessage, setShowConfirmationMessage] = useState(false);
  
  const navigate = useNavigate();
  const location = useLocation();
  const { login, register, user, loading: authLoading } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (!authLoading && user) {
      navigate('/dashboard');
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const ref = params.get('ref');
    if (ref) {
      localStorage.setItem('referralCode', ref);
      toast({ title: "مرحباً!", description: `لقد تمت دعوتك من قبل مستخدم. قم بالتسجيل للحصول على مكافأة!`, duration: 7000 });
    }
  }, [location.search, toast]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setPageLoading(true);
    setShowConfirmationMessage(false);

    if (isLogin) {
      const result = await login(email, password);
      if (result.success) {
        toast({ title: "تم تسجيل الدخول!", description: `مرحبًا بعودتك!` });
        navigate('/dashboard');
      } else {
        if (result.emailNotConfirmed) {
            toast({ title: "تفعيل الحساب مطلوب", description: "يرجى التحقق من بريدك الإلكتروني لتفعيل حسابك قبل تسجيل الدخول.", variant: "destructive", duration: 7000 });
        } else if (result.error && result.error.message.toLowerCase().includes("invalid login credentials")) {
            toast({ title: "خطأ في تسجيل الدخول", description: "البريد الإلكتروني أو كلمة المرور غير صحيحة.", variant: "destructive" });
        } else if (result.error) {
            toast({ title: "خطأ في تسجيل الدخول", description: result.error.message, variant: "destructive" });
        } else {
            toast({ title: "خطأ في تسجيل الدخول", description: "حدث خطأ غير متوقع.", variant: "destructive" });
        }
      }
    } else {
      if (password !== confirmPassword) {
        toast({ title: "خطأ في التسجيل", description: "كلمتا المرور غير متطابقتين.", variant: "destructive" });
        setPageLoading(false);
        return;
      }
      if (password.length < 6) {
        toast({ title: "خطأ في التسجيل", description: "يجب أن تكون كلمة المرور 6 أحرف على الأقل.", variant: "destructive" });
        setPageLoading(false);
        return;
      }
      const referralCode = localStorage.getItem('referralCode');
      const result = await register(username, password, email, referralCode);
      if (result.success) {
        if (result.needsConfirmation) {
            setShowConfirmationMessage(true);
        } else {
            toast({ title: "تم التسجيل بنجاح!", description: `مرحبًا بك في MEMEZAK، ${username}!` });
            navigate('/dashboard'); 
        }
        if(referralCode) localStorage.removeItem('referralCode');
      } else {
      }
    }
    setPageLoading(false);
  };

  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-900 text-white">
        <Loader2 className="h-12 w-12 animate-spin text-purple-500" />
      </div>
    );
  }

  if (showConfirmationMessage) {
    return (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex items-center justify-center min-h-[calc(100vh-200px)] py-12"
        >
            <Card className="w-full max-w-md bg-gray-800/70 border-green-500/40 shadow-2xl text-center">
                <CardHeader>
                    <MailCheck className="mx-auto h-16 w-16 text-green-400 mb-4" />
                    <CardTitle className="text-2xl font-bold text-gray-100">تم التسجيل بنجاح!</CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-gray-300">
                        مرحبًا بك في MEMEZAK، <span className="font-semibold text-purple-300">{username}</span>!
                    </p>
                    <p className="text-gray-300 mt-2">
                        لقد أرسلنا رسالة تفعيل إلى <span className="font-semibold text-purple-300">{email}</span>.
                    </p>
                    <p className="text-gray-300 mt-2">
                        يرجى التحقق من بريدك الإلكتروني (بما في ذلك مجلد الرسائل غير المرغوب فيها) والنقر على رابط التفعيل لإكمال عملية التسجيل وتسجيل الدخول.
                    </p>
                </CardContent>
                <CardFooter className="flex flex-col items-center space-y-3">
                    <Button onClick={() => { setShowConfirmationMessage(false); setIsLogin(true); }} className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white">
                        العودة إلى تسجيل الدخول
                    </Button>
                </CardFooter>
            </Card>
        </motion.div>
    );
  }


  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="flex items-center justify-center min-h-[calc(100vh-200px)] py-12"
    >
      <Card className="w-full max-w-md bg-gray-800/70 border-purple-500/40 shadow-2xl">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl font-bold text-gray-100">
            {isLogin ? 'تسجيل الدخول' : 'إنشاء حساب جديد'}
          </CardTitle>
          <CardDescription className="text-gray-400">
            {isLogin ? 'مرحبًا بعودتك! قم بتسجيل الدخول لمتابعة تعدين MEMEZAK.' : 'انضم إلى منصة MEMEZAK وابدأ رحلتك في عالم العملات الرقمية.'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {!isLogin && (
              <div className="space-y-2">
                <Label htmlFor="username">اسم المستخدم</Label>
                <Input 
                  id="username" 
                  type="text" 
                  placeholder="اسم المستخدم الخاص بك" 
                  value={username} 
                  onChange={(e) => setUsername(e.target.value)} 
                  required 
                  className="bg-gray-900/50 border-gray-700 focus:border-purple-500"
                />
              </div>
            )}
            <div className="space-y-2">
              <Label htmlFor="email">البريد الإلكتروني</Label>
              <Input 
                id="email" 
                type="email" 
                placeholder="بريدك الإلكتروني" 
                value={email} 
                onChange={(e) => setEmail(e.target.value)} 
                required
                className="bg-gray-900/50 border-gray-700 focus:border-purple-500"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">كلمة المرور</Label>
              <Input 
                id="password" 
                type="password" 
                placeholder="********" 
                value={password} 
                onChange={(e) => setPassword(e.target.value)} 
                required 
                className="bg-gray-900/50 border-gray-700 focus:border-purple-500"
              />
            </div>
            {!isLogin && (
              <div className="space-y-2">
                <Label htmlFor="confirmPassword">تأكيد كلمة المرور</Label>
                <Input 
                  id="confirmPassword" 
                  type="password" 
                  placeholder="********" 
                  value={confirmPassword} 
                  onChange={(e) => setConfirmPassword(e.target.value)} 
                  required 
                  className="bg-gray-900/50 border-gray-700 focus:border-purple-500"
                />
              </div>
            )}
            <Button type="submit" className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white py-3 text-lg" disabled={pageLoading}>
              {pageLoading ? <Loader2 className="mr-2 h-5 w-5 animate-spin"/> : (isLogin ? <LogIn className="mr-2 h-5 w-5"/> : <UserPlus className="mr-2 h-5 w-5"/>)}
              {isLogin ? 'تسجيل الدخول' : 'إنشاء حساب'}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="flex justify-center">
          <Button variant="link" onClick={() => { setIsLogin(!isLogin); setShowConfirmationMessage(false); }} className="text-purple-400 hover:text-purple-300" disabled={pageLoading}>
            {isLogin ? 'ليس لديك حساب؟ أنشئ واحدًا' : 'لديك حساب بالفعل؟ سجل الدخول'}
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default AuthPage;