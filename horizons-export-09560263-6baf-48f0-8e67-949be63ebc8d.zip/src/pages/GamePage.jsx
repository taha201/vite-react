import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Gem, Bomb, Shield, PlayCircle, RotateCcw, Star } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useMining } from '@/contexts/MiningContext';
import { useToast } from '@/components/ui/use-toast';

const GRID_SIZE = 4; // Simplified grid
const GAME_DURATION = 20; // Shorter game duration
const ITEM_TYPES = { GEM: 'gem', BOMB: 'bomb', STAR: 'star' };
const ITEM_SPAWN_INTERVAL = 1500; // Slower spawn rate
const TOKENS_PER_POINT = 0.005; // Adjusted token reward

const itemDefinitions = {
  [ITEM_TYPES.GEM]: { icon: Gem, color: 'text-green-400', points: 10, sound: '/sounds/gem.mp3' },
  [ITEM_TYPES.BOMB]: { icon: Bomb, color: 'text-red-500', points: -15, sound: '/sounds/bomb.mp3' },
  [ITEM_TYPES.STAR]: { icon: Star, color: 'text-yellow-400', points: 25, sound: '/sounds/star.mp3' }, // Star gives more points
};

const generateItem = () => {
  const rand = Math.random();
  if (rand < 0.6) return ITEM_TYPES.GEM; 
  if (rand < 0.85) return ITEM_TYPES.BOMB;
  return ITEM_TYPES.STAR;
};

const GameCell = React.memo(({ itemData, onClick }) => {
  const itemConfig = itemData ? itemDefinitions[itemData.type] : null;
  return (
    <motion.div
      className="bg-gray-700/30 rounded-lg flex items-center justify-center cursor-pointer hover:bg-purple-700/60 transition-all duration-150 ease-in-out aspect-square shadow-md"
      onClick={onClick}
      whileHover={{ scale: 1.05, boxShadow: "0px 0px 15px rgba(168, 85, 247, 0.5)" }}
      whileTap={{ scale: 0.95 }}
    >
      <AnimatePresence>
        {itemConfig && (
          <motion.div
            key={itemData.id}
            initial={{ scale: 0.5, opacity: 0, y: -20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.5, opacity: 0, y: 20, transition: { duration: 0.2 } }}
            transition={{ type: "spring", stiffness: 400, damping: 18 }}
          >
            <itemConfig.icon className={`h-10 w-10 sm:h-12 sm:w-12 ${itemConfig.color}`} />
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
});

const SuperMemezakGame = () => {
  const { addTokens } = useMining();
  const { toast } = useToast();
  const [grid, setGrid] = useState(Array(GRID_SIZE * GRID_SIZE).fill(null));
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(GAME_DURATION);
  const [isActive, setIsActive] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [highScore, setHighScore] = useState(() => parseInt(localStorage.getItem('memezakGameHighScore') || '0'));

  const audioRefs = useRef({
    gem: typeof Audio !== "undefined" ? new Audio('/sounds/gem.mp3') : null,
    bomb: typeof Audio !== "undefined" ? new Audio('/sounds/bomb.mp3') : null,
    star: typeof Audio !== "undefined" ? new Audio('/sounds/star.mp3') : null,
    gameOver: typeof Audio !== "undefined" ? new Audio('/sounds/gameover.mp3') : null,
  });

  const playSound = (soundType) => {
    if (audioRefs.current[soundType]) {
      audioRefs.current[soundType].currentTime = 0;
      audioRefs.current[soundType].play().catch(e => console.warn("Audio play failed:", e));
    }
  };

  const spawnItem = useCallback(() => {
    setGrid(prevGrid => {
      const newGrid = [...prevGrid];
      const emptyCells = newGrid.map((cell, idx) => cell === null ? idx : -1).filter(idx => idx !== -1);
      if (emptyCells.length === 0) return newGrid;
      
      const randomIndex = emptyCells[Math.floor(Math.random() * emptyCells.length)];
      const itemType = generateItem();
      newGrid[randomIndex] = { type: itemType, id: `${Date.now()}-${randomIndex}` };
      return newGrid;
    });
  }, []);

  useEffect(() => {
    let gameTimerInterval;
    let itemSpawnInterval;

    if (isActive && timeLeft > 0) {
      gameTimerInterval = setInterval(() => setTimeLeft(prev => prev - 1), 1000);
      itemSpawnInterval = setInterval(spawnItem, ITEM_SPAWN_INTERVAL);
    } else if (timeLeft === 0 && isActive) {
      setIsActive(false);
      setGameOver(true);
      playSound('gameOver');
      const earnedTokens = Math.max(0, score) * TOKENS_PER_POINT;
      if (score > highScore) {
        setHighScore(score);
        localStorage.setItem('memezakGameHighScore', score.toString());
      }
      if (earnedTokens > 0) {
        addTokens(earnedTokens, 'لعبة SuperMEMEZAK');
        toast({ title: "انتهت اللعبة!", description: `لقد ربحت ${earnedTokens.toFixed(3)} MEMZ! نتيجتك: ${score}`, variant: "default" });
      } else {
        toast({ title: "انتهت اللعبة!", description: `نتيجتك: ${score}. حظ أوفر في المرة القادمة!`, variant: "default" });
      }
    }
    return () => {
      clearInterval(gameTimerInterval);
      clearInterval(itemSpawnInterval);
    };
  }, [isActive, timeLeft, spawnItem, score, addTokens, toast, highScore]);

  const handleClick = useCallback((index) => {
    if (!isActive || !grid[index]) return;

    const item = grid[index];
    const itemConfig = itemDefinitions[item.type];
    
    playSound(item.type);

    setScore(prevScore => Math.max(0, prevScore + itemConfig.points));
    
    setGrid(prevGrid => {
      const newGrid = [...prevGrid];
      newGrid[index] = null;
      return newGrid;
    });
  }, [isActive, grid, playSound]);

  const startGame = () => {
    setScore(0);
    setTimeLeft(GAME_DURATION);
    setGrid(Array(GRID_SIZE * GRID_SIZE).fill(null));
    setIsActive(true);
    setGameOver(false);
    for(let i=0; i<2; i++) spawnItem(); // Spawn initial items
  };

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.4 }}
      className="flex flex-col items-center space-y-6"
    >
      <Card className="w-full max-w-sm sm:max-w-md bg-gray-800/80 backdrop-blur-md border-purple-600/50 shadow-2xl rounded-xl">
        <CardHeader className="text-center pb-4">
          <CardTitle className="text-4xl font-extrabold memezak-gradient-text">MEMEZAK Clicker</CardTitle>
          <CardDescription className="text-gray-300 text-sm">
            انقر على الجواهر والنجوم لجمع النقاط. تجنب القنابل!
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex justify-between items-center mb-6 p-3 bg-gray-900/60 rounded-lg shadow-inner">
            <div>
              <p className="text-xs text-gray-400">النقاط</p>
              <p className="text-2xl font-bold text-yellow-300">{score}</p>
            </div>
            <div>
              <p className="text-xs text-gray-400">أعلى نتيجة</p>
              <p className="text-lg font-bold text-purple-300">{highScore}</p>
            </div>
            <div>
              <p className="text-xs text-gray-400">الوقت</p>
              <p className="text-2xl font-bold text-orange-400">{timeLeft} ث</p>
            </div>
          </div>

          {!isActive && (
            <div className="text-center py-6">
              <Button 
                onClick={startGame} 
                size="lg" 
                className="bg-gradient-to-br from-purple-600 to-indigo-700 hover:from-purple-700 hover:to-indigo-800 text-white text-lg font-semibold py-3 px-8 rounded-lg shadow-lg transform hover:scale-105 transition-all duration-200"
              >
                {gameOver ? <RotateCcw className="mr-2 h-5 w-5"/> : <PlayCircle className="mr-2 h-5 w-5"/>}
                {gameOver ? "العب مرة أخرى" : "ابدأ اللعبة"}
              </Button>
              {gameOver && <p className="mt-4 text-md text-gray-200">النتيجة النهائية: {score} | ربحت: {(Math.max(0,score) * TOKENS_PER_POINT).toFixed(3)} MEMZ</p>}
               <p className="mt-2 text-xs text-gray-400">كل نقطة = {TOKENS_PER_POINT.toFixed(3)} MEMZ</p>
            </div>
          )}

          {isActive && (
            <div className={`grid grid-cols-${GRID_SIZE} gap-2 sm:gap-3 aspect-square bg-black/40 p-2 sm:p-3 rounded-lg shadow-inner`}>
              {grid.map((itemData, index) => (
                <GameCell key={index} itemData={itemData} onClick={() => handleClick(index)} />
              ))}
            </div>
          )}
        </CardContent>
      </Card>
      <div className="text-xs text-gray-400 text-center max-w-xs space-y-1 p-3 bg-gray-800/50 rounded-lg">
        <p><Gem className="inline h-4 w-4 text-green-400"/> = +{itemDefinitions[ITEM_TYPES.GEM].points} نقاط</p>
        <p><Star className="inline h-4 w-4 text-yellow-400"/> = +{itemDefinitions[ITEM_TYPES.STAR].points} نقاط</p>
        <p><Bomb className="inline h-4 w-4 text-red-500"/> = {itemDefinitions[ITEM_TYPES.BOMB].points} نقطة</p>
      </div>
      <div id="sounds" className="hidden">
        <audio id="audio-gem" src="/sounds/gem.mp3" preload="auto"></audio>
        <audio id="audio-bomb" src="/sounds/bomb.mp3" preload="auto"></audio>
        <audio id="audio-star" src="/sounds/star.mp3" preload="auto"></audio>
        <audio id="audio-gameOver" src="/sounds/gameover.mp3" preload="auto"></audio>
      </div>
    </motion.div>
  );
};

export default SuperMemezakGame;