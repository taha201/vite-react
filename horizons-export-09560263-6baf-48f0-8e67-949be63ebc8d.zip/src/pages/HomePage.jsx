import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Zap, ShieldCheck, Users, TrendingUp, Gift, Gamepad2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';

const FeatureCard = ({ icon, title, description, delay }) => (
  <motion.div
    initial={{ opacity: 0, y: 50 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5, delay }}
  >
    <Card className="bg-gray-800/50 border-purple-500/30 h-full hover:shadow-purple-500/30 hover:border-purple-500/70 transition-all duration-300">
      <CardHeader className="items-center text-center">
        {React.createElement(icon, { className: "h-12 w-12 mb-4 text-purple-400" })}
        <CardTitle className="text-xl text-gray-100">{title}</CardTitle>
      </CardHeader>
      <CardContent className="text-center">
        <CardDescription className="text-gray-300">{description}</CardDescription>
      </CardContent>
    </Card>
  </motion.div>
);

const HomePage = () => {
  const navigate = useNavigate();
  const { user } = useAuth();

  const handleGetStarted = () => {
    if (user) {
      navigate('/dashboard');
    } else {
      navigate('/auth');
    }
  };

  return (
    <div className="space-y-16">
      {/* Hero Section */}
      <motion.section 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1 }}
        className="text-center py-16 md:py-24 bg-gradient-to-b from-purple-900/30 to-transparent rounded-xl shadow-2xl overflow-hidden"
      >
        <div className="absolute inset-0 opacity-10">
          
          <img  alt="Abstract background for MEMEZAK hero section" className="w-full h-full object-cover" src="https://images.unsplash.com/photo-1662896204466-2a2485b88989" />
        </div>
        <div className="relative z-10">
          <motion.h1 
            initial={{ y: -50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.7, delay: 0.2, type: 'spring' }}
            className="text-5xl md:text-7xl font-extrabold mb-6"
          >
            <span className="memezak-gradient-text">MEMEZAK</span>
          </motion.h1>
          <motion.p 
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.7, delay: 0.4, type: 'spring' }}
            className="text-xl md:text-2xl text-gray-300 mb-10 max-w-3xl mx-auto px-4"
          >
            انضم إلى ثورة تعدين العملات الرقمية مع MEMEZAK. ابدأ التعدين اليوم واكسب عملات MEMZ القيمة!
          </motion.p>
          <motion.div
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.6, type: 'spring' }}
          >
            <Button 
              size="lg" 
              onClick={handleGetStarted} 
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold text-lg py-3 px-8 rounded-lg shadow-lg transform hover:scale-105 transition-transform duration-300"
            >
              ابدأ الآن مجانًا
            </Button>
          </motion.div>
        </div>
      </motion.section>

      {/* Features Section */}
      <section className="py-12">
        <h2 className="text-4xl font-bold text-center mb-12 text-gray-100">لماذا تختار <span className="memezak-gradient-text">MEMEZAK</span>؟</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          <FeatureCard icon={Zap} title="تعدين فوري" description="ابدأ تعدين عملات MEMZ فور تسجيلك. لا حاجة لأجهزة معقدة." delay={0.1} />
          <FeatureCard icon={ShieldCheck} title="آمن وموثوق" description="نظامنا مصمم لحماية أرباحك وبياناتك بأحدث تقنيات الأمان." delay={0.2} />
          <FeatureCard icon={Gift} title="تعدين مجاني ومدفوع" description="اختر من بين باقات التعدين المجانية أو المطورة لزيادة أرباحك." delay={0.3} />
          <FeatureCard icon={Users} title="نظام إحالات مربح" description="ادعُ أصدقاءك واكسب المزيد من عملات MEMZ عن طريق نظام الإحالات." delay={0.4} />
          <FeatureCard icon={TrendingUp} title="إمكانيات نمو واعدة" description="عملة MEMEZAK هي عملة ذات مستقبل واعد في عالم العملات الرقمية." delay={0.5} />
          <FeatureCard icon={Gamepad2} title="العب واكسب" description="استمتع بلعبة SuperMEMEZAK واجمع المزيد من التوكنات بطريقة ممتعة." delay={0.6} />
        </div>
      </section>

      {/* Call to Action Section */}
      <motion.section 
        initial={{ opacity: 0, y:50 }}
        animate={{ opacity: 1, y:0 }}
        transition={{ duration: 0.5, delay: 0.5 }}
        className="py-16 bg-gray-800/60 rounded-xl shadow-xl text-center"
      >
        <h2 className="text-3xl font-bold mb-6 text-gray-100">هل أنت مستعد لبدء رحلتك في عالم <span className="memezak-gradient-text">MEMEZAK</span>؟</h2>
        <p className="text-lg text-gray-300 mb-8 max-w-xl mx-auto">
          لا تفوت الفرصة لتكون جزءًا من مجتمعنا المتنامي. انضم اليوم وابدأ في جمع عملات MEMZ.
        </p>
        <Button 
          size="lg" 
          onClick={handleGetStarted}
          className="bg-gradient-to-r from-pink-500 to-orange-500 hover:from-pink-600 hover:to-orange-600 text-white font-semibold text-lg py-3 px-8 rounded-lg shadow-lg transform hover:scale-105 transition-transform duration-300"
        >
          انضم إلى المنصة
        </Button>
      </motion.section>
    </div>
  );
};

export default HomePage;