import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { CheckCircle, Youtube, MessageSquare, ThumbsUp, Loader2, AlertTriangle } from 'lucide-react';
import { useMining } from '@/contexts/MiningContext';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';
import TaskCard from '@/components/tasks/TaskCard';

const tasksData = [
  {
    id: 'youtube_watch',
    title: 'شاهد فيديو يوتيوب',
    description: 'شاهد الفيديو الترويجي لـ MEMEZAK لمدة دقيقة واحدة.',
    reward: 10,
    icon: Youtube,
    actionText: 'شاهد الآن',
    actionLink: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', 
    type: 'external_link',
    duration: 60000, 
  },
  {
    id: 'telegram_join',
    title: 'انضم إلى قناتنا على تيليجرام',
    description: 'كن على اطلاع دائم بآخر الأخبار والتحديثات.',
    reward: 15,
    icon: MessageSquare,
    actionText: 'انضم الآن',
    actionLink: 'https://t.me/your_telegram_channel', 
    type: 'external_link',
  },
  {
    id: 'twitter_follow',
    title: 'تابعنا على تويتر (X)',
    description: 'تابع حسابنا الرسمي على منصة X.',
    reward: 12,
    icon: () => (
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
        <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
      </svg>
    ),
    actionText: 'تابع الآن',
    actionLink: 'https://twitter.com/your_twitter_handle',
    type: 'external_link',
  },
  {
    id: 'daily_login',
    title: 'تسجيل الدخول اليومي',
    description: 'سجل دخولك يوميًا للحصول على مكافأة.',
    reward: 5,
    icon: CheckCircle,
    type: 'auto_completed', 
  },
  {
    id: 'like_post',
    title: 'أعجب بمنشورنا الأخير',
    description: 'ادعمنا بإعجاب على آخر منشور لنا على منصة X.',
    reward: 8,
    icon: ThumbsUp,
    actionText: 'أعجب بالمنشور',
    actionLink: 'https://twitter.com/your_twitter_handle/latest_post', 
    type: 'external_link',
  }
];


const TasksPage = () => {
  const { user } = useAuth();
  const { miningData, updateMiningData, loading: miningLoading } = useMining();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [loadingTask, setLoadingTask] = useState(null);
  const [completedTasks, setCompletedTasks] = useState([]);

  useEffect(() => {
    if (miningData?.tasks_completed) {
      setCompletedTasks(Object.keys(miningData.tasks_completed).filter(taskId => miningData.tasks_completed[taskId]));
    }
  }, [miningData]);

  useEffect(() => {
    const checkDailyLogin = async () => {
      if (user && miningData && !miningData.loading) {
        const dailyLoginTask = tasksData.find(t => t.id === 'daily_login');
        if (dailyLoginTask && !isTaskCompleted('daily_login')) {
          const today = new Date().toDateString();
          const lastLoginDate = miningData.tasks_completed?.daily_login_date;
          
          if (lastLoginDate !== today) {
            await handleCompleteTask('daily_login', dailyLoginTask.reward, true);
            await updateMiningData({ 
              tasks_completed: { 
                ...miningData.tasks_completed, 
                daily_login_date: today 
              } 
            });
          } else {
            if (!completedTasks.includes('daily_login')) {
               setCompletedTasks(prev => [...prev, 'daily_login']);
            }
          }
        }
      }
    };
    checkDailyLogin();
  }, [user, miningData]);


  const isTaskCompleted = (taskId) => {
    return completedTasks.includes(taskId);
  };

  const handleCompleteTask = async (taskId, reward, isAuto = false) => {
    if (!user || !miningData) {
      toast({ title: "خطأ", description: "يجب تسجيل الدخول أولاً.", variant: "destructive" });
      return;
    }
    if (isTaskCompleted(taskId) && !isAuto) {
      toast({ title: "مهمة مكتملة", description: "لقد أكملت هذه المهمة بالفعل.", variant: "default" });
      return;
    }

    setLoadingTask(taskId);
    try {
      const newBalance = (parseFloat(miningData.balance) || 0) + reward;
      const updatedTasksCompleted = { ...miningData.tasks_completed, [taskId]: true };

      await updateMiningData({
        balance: newBalance,
        tasks_completed: updatedTasksCompleted,
      });

      setCompletedTasks(prev => [...prev, taskId]);
      if (!isAuto) {
        toast({
          title: "مهمة مكتملة!",
          description: `تمت إضافة ${reward} MEMZ إلى رصيدك.`,
          className: "bg-green-600 border-green-700 text-white",
        });
      } else {
         toast({
          title: "مكافأة تسجيل الدخول اليومي!",
          description: `تمت إضافة ${reward} MEMZ إلى رصيدك لتسجيل دخولك اليوم.`,
          className: "bg-blue-600 border-blue-700 text-white",
        });
      }
    } catch (error) {
      console.error("Error completing task:", error);
      toast({ title: "خطأ", description: "لم نتمكن من إكمال المهمة. حاول مرة أخرى.", variant: "destructive" });
    } finally {
      setLoadingTask(null);
    }
  };
  
  if (miningLoading && !miningData) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-200px)]">
        <Loader2 className="h-12 w-12 animate-spin text-purple-400" />
      </div>
    );
  }

  if (!user) {
     return (
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-200px)] text-center px-4">
        <AlertTriangle className="h-16 w-16 text-yellow-400 mb-4" />
        <h1 className="text-2xl font-bold text-gray-100 mb-2">يرجى تسجيل الدخول</h1>
        <p className="text-gray-300 mb-6">يجب عليك تسجيل الدخول لعرض المهام المتاحة وإكمالها.</p>
        <Button onClick={() => navigate('/auth')} className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white">
          الذهاب إلى صفحة التسجيل
        </Button>
      </div>
    );
  }


  return (
    <div className="container mx-auto py-8 px-4">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl font-bold text-center mb-4 text-gray-100">
          مركز المهام <span className="memezak-gradient-text">MEMEZAK</span>
        </h1>
        <p className="text-lg text-center text-gray-300 mb-10 max-w-2xl mx-auto">
          أكمل المهام التالية لكسب المزيد من عملات MEMZ وزيادة رصيدك. يتم تحديث المهام بانتظام!
        </p>
      </motion.div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {tasksData.map((task) => (
          <TaskCard 
            key={task.id} 
            task={task} 
            onComplete={handleCompleteTask}
            completed={isTaskCompleted(task.id)}
            loadingTask={loadingTask}
          />
        ))}
      </div>
    </div>
  );
};

export default TasksPage;