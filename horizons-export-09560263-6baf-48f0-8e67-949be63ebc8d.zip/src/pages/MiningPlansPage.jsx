import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Zap, Star, Shield, Gem, ArrowRightCircle } from 'lucide-react';
import { useMining } from '@/contexts/MiningContext';
import { useToast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';
import { PLANS } from '@/contexts/miningConfig'; // Import PLANS from config

// Transform PLANS object into an array for mapping, and add extra UI properties
const plansArray = Object.entries(PLANS).map(([id, planData]) => {
  let icon = Gem;
  let color = "from-gray-500 to-gray-700";
  let borderColor = "border-gray-500";
  let highlight = false;

  if (id === "weekly") { icon = Zap; color = "from-blue-500 to-indigo-600"; borderColor = "border-blue-500"; }
  else if (id === "monthly") { icon = Star; color = "from-purple-500 to-pink-600"; borderColor = "border-purple-500"; }
  else if (id === "yearly") { icon = Shield; color = "from-yellow-400 to-orange-500"; borderColor = "border-yellow-500"; }
  else if (id === "vip_turbomax") { icon = Shield; color = "from-red-500 to-red-700"; borderColor = "border-red-500"; highlight = true; }
  
  // Define features based on plan ID or properties
  let features = ["تعدين أساسي", `مطالبة كل ${planData.claimInterval / (60*60*1000)} ساعات`, "دعم محدود"];
  if (id === "weekly") features = ["سرعة تعدين 5x", `مطالبة كل ${planData.claimInterval / (60*60*1000)} ساعات`, "دعم أساسي"];
  if (id === "monthly") features = ["سرعة تعدين 15x", `مطالبة كل ${planData.claimInterval / (60*60*1000)} ساعة`, "أولوية الدعم", "مكافأة تسجيل"];
  if (id === "yearly") features = ["سرعة تعدين 50x", `مطالبة كل ${planData.claimInterval / (60*1000)} دقيقة`, "دعم VIP", "مكافآت حصرية", "خصم 20%"];
  if (id === "vip_turbomax") features = ["سرعة تعدين 200x (تيربو ماكس)", "مطالبة فورية", "دعم شخصي فوري", "ميزات تجريبية مبكرة", "شارة VIP"];


  return {
    ...planData,
    id,
    priceFrequency: id === "free" ? "دائمًا" : (id === "weekly" ? "/أسبوع" : (id === "monthly" ? "/شهر" : "/سنة")),
    icon,
    color,
    borderColor,
    highlight,
    features
  };
});


const PlanCard = ({ plan, onSelectPlan, currentPlanId }) => (
  <motion.div
    initial={{ opacity: 0, y: 50 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5, delay: Math.random() * 0.5 }}
    whileHover={{ y: -10, boxShadow: `0px 0px 30px ${plan.borderColor.replace('border-','')}-500/50`}}
    className={`relative flex flex-col rounded-xl bg-gray-800/70 border ${plan.borderColor} shadow-xl overflow-hidden ${plan.highlight ? 'ring-4 ring-offset-2 ring-offset-background ring-yellow-400' : ''} ${currentPlanId === plan.id ? 'ring-2 ring-green-400 ring-offset-background' : ''}`}
  >
    {plan.highlight && (
      <div className="absolute top-0 right-0 bg-yellow-400 text-gray-900 px-3 py-1 text-xs font-bold rounded-bl-lg z-10">
        الأكثر شيوعًا
      </div>
    )}
     {currentPlanId === plan.id && (
      <div className="absolute top-2 left-2 bg-green-500 text-white px-2 py-0.5 text-xs font-bold rounded-md z-10">
        الباقة الحالية
      </div>
    )}
    <CardHeader className="items-center text-center pt-8 pb-4">
      {React.createElement(plan.icon, { className: `h-16 w-16 mb-4 bg-gradient-to-br ${plan.color} p-3 rounded-full text-white` })}
      <CardTitle className="text-3xl font-bold text-gray-100">{plan.name}</CardTitle>
      <div className="flex items-baseline justify-center">
        <span className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r ${plan.color} mr-1">{plan.price} MEMZ</span>
        <span className="text-sm text-gray-400">{plan.priceFrequency}</span>
      </div>
      <CardDescription className="text-gray-300 pt-2">سرعة تعدين: {plan.rate.toFixed(6)} MEMZ/ساعة</CardDescription>
    </CardHeader>
    <CardContent className="flex-grow">
      <ul className="space-y-2 text-gray-300">
        {plan.features.map((feature, index) => (
          <li key={index} className="flex items-center">
            <ArrowRightCircle className="h-5 w-5 text-green-400 mr-2 rtl:ml-2 rtl:mr-0" />
            {feature}
          </li>
        ))}
      </ul>
    </CardContent>
    <CardFooter className="mt-auto p-6">
      <Button 
        onClick={() => onSelectPlan(plan)}
        className={`w-full bg-gradient-to-r ${plan.color} hover:opacity-90 text-white font-semibold py-3 text-lg rounded-md shadow-md transform hover:scale-105 transition-transform duration-300`}
        disabled={currentPlanId === plan.id}
      >
        {currentPlanId === plan.id ? "الباقة الحالية" : "اختر الباقة"}
      </Button>
    </CardFooter>
  </motion.div>
);


const MiningPlansPage = () => {
  const { upgradePlan, miningData } = useMining();
  const { toast } = useToast();

  const handleSelectPlan = (plan) => {
    if (miningData.currentPlanId === plan.id) {
      toast({
        title: "معلومة",
        description: `أنت بالفعل مشترك في باقة ${plan.name}.`,
        variant: "default"
      });
      return;
    }
    
    const success = upgradePlan(plan.id, plan.rate); 
    if(success){
       toast({
        title: "تمت الترقية!",
        description: `لقد اشتركت بنجاح في باقة ${plan.name}.`,
      });
    } else {
       toast({
        title: "خطأ في الترقية",
        description: `رصيدك غير كافٍ للاشتراك في باقة ${plan.name}. أو حدث خطأ آخر.`,
        variant: "destructive"
      });
    }
  };

  return (
    <div className="space-y-12">
      <motion.div 
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center"
      >
        <h1 className="text-5xl font-extrabold mb-4 text-gray-100">باقات التعدين</h1>
        <p className="text-xl text-gray-300 max-w-2xl mx-auto">
          اختر الباقة التي تناسب طموحاتك في تعدين <span className="memezak-gradient-text font-bold">MEMEZAK</span>. زد أرباحك وسرّع عملية التعدين!
        </p>
      </motion.div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 items-stretch">
        {plansArray.map((plan) => (
          <PlanCard key={plan.id} plan={plan} onSelectPlan={handleSelectPlan} currentPlanId={miningData.currentPlanId} />
        ))}
      </div>

      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.8 }}
        className="text-center mt-12 p-8 bg-gray-800/50 rounded-lg shadow-lg border border-purple-500/30"
      >
        <h2 className="text-2xl font-semibold mb-4 text-gray-100">ملاحظات هامة:</h2>
        <ul className="list-disc list-inside text-gray-400 space-y-2 text-right mx-auto max-w-md">
          <li>جميع الأسعار المعروضة بعملة MEMZ ويتم خصمها من رصيدك داخل المنصة.</li>
          <li>في التطبيق الفعلي، قد يتم توجيهك لصفحة دفع آمنة لإتمام عملية الشراء بالعملات الحقيقية.</li>
          <li>يمكنك ترقية باقتك في أي وقت.</li>
        </ul>
      </motion.div>
    </div>
  );
};

export default MiningPlansPage;