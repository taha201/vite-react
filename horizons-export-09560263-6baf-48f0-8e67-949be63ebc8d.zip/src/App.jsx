import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Layout from '@/components/shared/Layout';
import HomePage from '@/pages/HomePage';
import DashboardPage from '@/pages/DashboardPage';
import MiningPlansPage from '@/pages/MiningPlansPage';
import ProfilePage from '@/pages/ProfilePage';
import GamePage from '@/pages/GamePage';
import TasksPage from '@/pages/TasksPage';
import AuthPage from '@/pages/AuthPage';
import { Toaster } from '@/components/ui/toaster';
import { AuthProvider } from '@/contexts/AuthContext';
import { MiningProvider } from '@/contexts/MiningContext';
import ProtectedRoute from '@/components/shared/ProtectedRoute';

function App() {
  return (
    <AuthProvider>
      <MiningProvider>
        <Router>
          <Layout>
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/auth" element={<AuthPage />} />
              <Route 
                path="/dashboard" 
                element={
                  <ProtectedRoute>
                    <DashboardPage />
                  </ProtectedRoute>
                } 
              />
              <Route 
                path="/mining-plans" 
                element={
                  <ProtectedRoute>
                    <MiningPlansPage />
                  </ProtectedRoute>
                } 
              />
              <Route 
                path="/profile" 
                element={
                  <ProtectedRoute>
                    <ProfilePage />
                  </ProtectedRoute>
                } 
              />
              <Route 
                path="/game" 
                element={
                  <ProtectedRoute>
                    <GamePage />
                  </ProtectedRoute>
                } 
              />
              <Route 
                path="/tasks" 
                element={
                  <ProtectedRoute>
                    <TasksPage />
                  </ProtectedRoute>
                } 
              />
            </Routes>
          </Layout>
          <Toaster />
        </Router>
      </MiningProvider>
    </AuthProvider>
  );
}

export default App;