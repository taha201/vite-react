import { PLANS, FREE_CLAIM_AMOUNT } from '@/contexts/miningConfig';
import { supabase } from '@/lib/supabaseClient';


export const recordTransactionInternal = async (userId, type, description, amount) => {
  if (!userId) return;
  try {
    const { error } = await supabase.from('transaction_history').insert([
      { user_id: userId, type, description, amount, date: new Date().toISOString() }
    ]);
    if (error) {
      console.error('Error recording transaction:', error);
    }
  } catch (e) {
    console.error('Exception recording transaction:', e);
  }
};


export const claimFreeTokensInternal = async (userId, miningData, setMiningDataCallback) => {
  if (!userId) return { success: false, message: "المستخدم غير مسجل الدخول." };

  const now = Date.now();
  if (now < miningData.next_claim_time) {
    return { success: false, message: `يمكنك المطالبة مرة أخرى بعد ${new Date(miningData.next_claim_time).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}.` };
  }

  const claimedAmount = miningData.accumulated_since_last_claim + FREE_CLAIM_AMOUNT;
  const newBalance = miningData.balance + claimedAmount;
  const currentPlanDetails = PLANS[miningData.current_plan_id] || PLANS.free;
  const claimInterval = currentPlanDetails.claimInterval;
  const newNextClaimTime = now + claimInterval;

  const { error } = await supabase
    .from('mining_data')
    .update({
      balance: newBalance,
      last_claim_time: new Date(now).toISOString(),
      next_claim_time: new Date(newNextClaimTime).toISOString(),
      can_claim: false,
      accumulated_since_last_claim: 0,
    })
    .eq('user_id', userId);

  if (error) {
    console.error("Error claiming tokens in Supabase:", error);
    return { success: false, message: "حدث خطأ أثناء المطالبة." };
  }

  await recordTransactionInternal(userId, 'claim', 'مطالبة بالتوكن المجاني والمعدن', claimedAmount);
  
  // Update local state via callback if provided (used by old context structure, might be removed)
  if (setMiningDataCallback) {
    setMiningDataCallback(prev => ({
      ...prev,
      balance: newBalance,
      last_claim_time: now,
      next_claim_time: newNextClaimTime,
      can_claim: false,
      accumulated_since_last_claim: 0,
    }));
  }
  
  return { success: true, message: `تمت المطالبة بـ ${claimedAmount.toFixed(18)} MEMZ.`, amount: claimedAmount };
};


export const upgradePlanInternal = async (userId, currentBalance, planId) => {
  if (!userId) return false;
  const plan = PLANS[planId];
  if (!plan) return false;

  if (currentBalance < plan.price && planId !== 'free') {
    return false; // Insufficient balance
  }
  
  const newBalance = planId === 'free' ? currentBalance : currentBalance - plan.price;
  const now = Date.now();
  const newNextClaimTime = now + (plan.claimInterval || PLANS.free.claimInterval);

  const { error } = await supabase
    .from('mining_data')
    .update({
      balance: newBalance,
      mining_rate: plan.rate,
      current_plan_id: planId,
      last_claim_time: new Date(now).toISOString(),
      next_claim_time: new Date(newNextClaimTime).toISOString(),
      can_claim: plan.claimInterval === 0,
      accumulated_since_last_claim: 0,
    })
    .eq('user_id', userId);

  if (error) {
    console.error("Error upgrading plan in Supabase:", error);
    return false;
  }
  
  if (planId !== 'free') {
      await recordTransactionInternal(userId, 'upgrade', `ترقية إلى باقة ${plan.name}`, -plan.price);
  }
  return true;
};


export const addTokensInternal = async (userId, currentBalance, amount, reason = "مكافأة") => {
  if (!userId || amount <= 0) return;
  
  const newBalance = currentBalance + amount;
  const { error } = await supabase
    .from('mining_data')
    .update({ balance: newBalance })
    .eq('user_id', userId);

  if (error) {
    console.error("Error adding tokens in Supabase:", error);
    return;
  }
  await recordTransactionInternal(userId, 'reward', reason, amount);
};


export const completeTaskInternal = async (userId, currentBalance, currentTasksCompleted, taskId, rewardAmount, taskName) => {
  if(!userId) return false;
  const today = new Date().toDateString();
  if(currentTasksCompleted && currentTasksCompleted[taskId] === today) {
      return false; 
  }

  const newBalance = currentBalance + rewardAmount;
  const newTasksCompleted = { ...(currentTasksCompleted || {}), [taskId]: today };

  const { error } = await supabase
    .from('mining_data')
    .update({ 
      balance: newBalance,
      tasks_completed: newTasksCompleted,
    })
    .eq('user_id', userId);
  
  if (error) {
    console.error("Error completing task in Supabase:", error);
    return false;
  }

  await recordTransactionInternal(userId, 'task_reward', `مكافأة إكمال مهمة: ${taskName}`, rewardAmount);
  return true;
};


export const withdrawTokensInternal = async (userId, currentBalance, minWithdrawal, amount, address, network) => {
  if (!userId || amount <= 0 || !address || !network) return { success: false, message: "بيانات السحب غير مكتملة." };
  
  if (currentBalance < amount) {
    return { success: false, message: "رصيدك غير كافٍ لإتمام عملية السحب." };
  }
  if (amount < minWithdrawal) { 
      return { success: false, message: `الحد الأدنى للسحب هو ${minWithdrawal} MEMZ.` };
  }

  const newBalance = currentBalance - amount;
  const { error } = await supabase
    .from('mining_data')
    .update({ balance: newBalance })
    .eq('user_id', userId);

  if (error) {
    console.error("Error withdrawing tokens in Supabase:", error);
    return { success: false, message: "حدث خطأ أثناء طلب السحب." };
  }
  
  await recordTransactionInternal(userId, 'withdraw_request', `طلب سحب ${amount.toFixed(18)} MEMZ إلى ${network} (${address})`, -amount);
  return { success: true, message: `تم طلب سحب ${amount.toFixed(18)} MEMZ بنجاح. ستتم معالجته قريبًا.`, amount };
};