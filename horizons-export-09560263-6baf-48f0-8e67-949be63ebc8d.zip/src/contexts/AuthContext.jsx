import React, { createContext, useState, useContext, useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [emailNeedsConfirmation, setEmailNeedsConfirmation] = useState(false);
  const { toast } = useToast();

  const fetchUserProfile = async (userId, userData) => {
    const { data: profile, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single();

    if (error && error.code !== 'PGRST116') {
      console.error('Error fetching profile:', error);
      toast({ title: "خطأ", description: "لم يتمكن من تحميل ملف المستخدم.", variant: "destructive" });
      return { id: userId, email: userData.email, ...userData.user_metadata };
    }
    return profile || { id: userId, email: userData.email, ...userData.user_metadata };
  };

  useEffect(() => {
    setLoading(true);
    setEmailNeedsConfirmation(false);
    const { data: authListener } = supabase.auth.onAuthStateChange(async (_event, session) => {
      if (session?.user) {
        if (session.user.email_confirmed_at || session.user.phone_confirmed_at) {
          const userProfile = await fetchUserProfile(session.user.id, session.user);
          setUser(userProfile);
          setEmailNeedsConfirmation(false);
        } else {
          setUser({ id: session.user.id, email: session.user.email, ...session.user.user_metadata });
          setEmailNeedsConfirmation(true);
        }
      } else {
        setUser(null);
        setEmailNeedsConfirmation(false);
      }
      setLoading(false);
    });

    return () => {
      authListener?.subscription.unsubscribe();
    };
  }, [toast]);

  const login = async (email, password) => {
    setLoading(true);
    setEmailNeedsConfirmation(false);
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    setLoading(false);

    if (error) {
      console.error('Login error:', error);
      if (error.message.toLowerCase().includes("email not confirmed")) {
        setEmailNeedsConfirmation(true);
        return { success: false, error, emailNotConfirmed: true };
      }
      return { success: false, error };
    }

    if (data.user) {
      if (!data.user.email_confirmed_at && !data.user.phone_confirmed_at) {
        setEmailNeedsConfirmation(true);
        setUser({ id: data.user.id, email: data.user.email, ...data.user.user_metadata });
        return { success: true, user: data.user, emailNotConfirmed: true };
      }
      const userProfile = await fetchUserProfile(data.user.id, data.user);
      setUser(userProfile);
      setEmailNeedsConfirmation(false);
      return { success: true, user: userProfile };
    }
    return { success: false, error: { message: "Unknown login error" } };
  };

  const register = async (username, password, email, referralCode) => {
    setLoading(true);
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          username: username,
          referred_by: referralCode || null,
        }
      }
    });
    setLoading(false);

    if (error) {
      console.error('Registration error:', error);
      if (error.message.includes("User already registered")) {
        toast({ title: "خطأ في التسجيل", description: "هذا البريد الإلكتروني مسجل بالفعل.", variant: "destructive" });
      } else if (error.message.includes("Password should be at least 6 characters.")) {
        toast({ title: "خطأ في التسجيل", description: "يجب أن تكون كلمة المرور 6 أحرف على الأقل.", variant: "destructive" });
      } else if (error.message.toLowerCase().includes("email address") && error.message.toLowerCase().includes("invalid")) {
        toast({ title: "خطأ في التسجيل", description: "صيغة البريد الإلكتروني غير صالحة. يرجى التحقق من البريد المدخل.", variant: "destructive" });
      } else {
        toast({ title: "خطأ في التسجيل", description: error.message, variant: "destructive" });
      }
      return { success: false, error };
    }
    
    if (data.user) {
      setEmailNeedsConfirmation(true);
      return { success: true, user: data.user, needsConfirmation: true };
    }
    
    return { success: false, error: { message: "Unknown registration error" } };
  };

  const logout = async () => {
    setLoading(true);
    const { error } = await supabase.auth.signOut();
    setLoading(false);
    if (error) {
      console.error('Logout error:', error);
      toast({ title: "خطأ", description: "حدث خطأ أثناء تسجيل الخروج.", variant: "destructive" });
    } else {
      setUser(null);
      setEmailNeedsConfirmation(false);
    }
  };
  
  const updateUserProfile = async (updatedProfileData) => {
    if (!user) return;
    setLoading(true);
    const { data, error } = await supabase
      .from('profiles')
      .update(updatedProfileData)
      .eq('id', user.id)
      .select()
      .single();
    setLoading(false);

    if (error) {
      console.error('Error updating profile:', error);
      toast({ title: "خطأ", description: "لم يتمكن من تحديث الملف الشخصي.", variant: "destructive" });
      return null;
    }
    setUser(data);
    toast({ title: "تم بنجاح", description: "تم تحديث ملفك الشخصي." });
    return data;
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout, updateUser: updateUserProfile, loading, emailNeedsConfirmation }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);