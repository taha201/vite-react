import React, { createContext, useState, useContext, useEffect, useCallback } from 'react';
import { useAuth } from './AuthContext';
import { supabase } from '@/lib/supabaseClient';
import { PLANS, INITIAL_MINING_DATA, FREE_CLAIM_AMOUNT } from './miningConfig';
import { 
  recordTransactionInternal, 
  claimFreeTokensInternal, 
  upgradePlanInternal, 
  addTokensInternal, 
  completeTaskInternal, 
  withdrawTokensInternal 
} from './miningActions';

const MiningContext = createContext(null);

export const MiningProvider = ({ children }) => {
  const { user, loading: authLoading } = useAuth();
  const [miningData, setMiningData] = useState(INITIAL_MINING_DATA);
  const [loading, setLoading] = useState(true);
  const userId = user?.id;

  const fetchMiningData = useCallback(async (currentUserId) => {
    if (!currentUserId) {
      setMiningData(INITIAL_MINING_DATA);
      setLoading(false);
      return;
    }
    setLoading(true);
    const { data, error } = await supabase
      .from('mining_data')
      .select('*')
      .eq('user_id', currentUserId)
      .single();

    if (error && error.code !== 'PGRST116') { 
      console.error('Error fetching mining data:', error);
      setMiningData(INITIAL_MINING_DATA); 
    } else if (data) {
      setMiningData(prev => ({
        ...INITIAL_MINING_DATA, 
        ...prev, 
        ...data,
        balance: parseFloat(data.balance),
        mining_rate: parseFloat(data.mining_rate),
        total_referral_earnings: parseFloat(data.total_referral_earnings),
        accumulated_since_last_claim: parseFloat(data.accumulated_since_last_claim),
        freeClaimAmount: FREE_CLAIM_AMOUNT, 
        referralBonus: INITIAL_MINING_DATA.referralBonus,
        minWithdrawalAmount: INITIAL_MINING_DATA.minWithdrawalAmount,
        next_claim_time: new Date(data.next_claim_time).getTime(),
        last_claim_time: new Date(data.last_claim_time).getTime(),
      }));
    } else {
      const initialUserData = {
        ...INITIAL_MINING_DATA,
        balance: user?.referred_by ? INITIAL_MINING_DATA.referralBonus : 0,
      };
      setMiningData(initialUserData);
    }
    setLoading(false);
  }, [user?.referred_by]);


  useEffect(() => {
    if (!authLoading) {
        fetchMiningData(userId);
    }
  }, [userId, authLoading, fetchMiningData]);


  useEffect(() => {
    if (!userId || !miningData.current_plan_id || loading) return;

    const interval = setInterval(() => {
      setMiningData(prev => {
        if (!prev.current_plan_id) return prev; 
        const now = Date.now();
        
        const hourlyRate = prev.mining_rate;
        const perSecondRate = hourlyRate / 3600;
        const newlyMined = perSecondRate * 1;
        
        let newAccumulated = prev.accumulated_since_last_claim + newlyMined;
        let canClaimNow = now >= prev.next_claim_time;
        
        return {
          ...prev,
          can_claim: canClaimNow,
          accumulated_since_last_claim: newAccumulated,
        };
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [userId, miningData.current_plan_id, miningData.next_claim_time, loading]);

  const claimFreeTokens = useCallback(async () => {
    const result = await claimFreeTokensInternal(userId, miningData);
    if (result.success) {
      await fetchMiningData(userId); // Re-fetch to ensure sync
    }
    return result;
  }, [userId, miningData, fetchMiningData]);

  const upgradePlan = useCallback(async (planId) => {
    const success = await upgradePlanInternal(userId, miningData.balance, planId);
    if (success) {
      await fetchMiningData(userId);
    }
    return success;
  }, [userId, miningData.balance, fetchMiningData]);

  const addTokens = useCallback(async (amount, reason = "مكافأة") => {
    await addTokensInternal(userId, miningData.balance, amount, reason);
    await fetchMiningData(userId);
  }, [userId, miningData.balance, fetchMiningData]);
  
  const completeTask = useCallback(async (taskId, rewardAmount, taskName) => {
    const success = await completeTaskInternal(userId, miningData.balance, miningData.tasks_completed, taskId, rewardAmount, taskName);
    if(success) {
        await fetchMiningData(userId);
    }
    return success;
  }, [userId, miningData.balance, miningData.tasks_completed, fetchMiningData]);

  const withdrawTokens = useCallback(async (amount, address, network) => {
    const result = await withdrawTokensInternal(userId, miningData.balance, miningData.minWithdrawalAmount, amount, address, network);
    if (result.success) {
      await fetchMiningData(userId);
    }
    return result;
  }, [userId, miningData.balance, miningData.minWithdrawalAmount, fetchMiningData]);

  return (
    <MiningContext.Provider value={{ miningData, claimFreeTokens, upgradePlan, addTokens, completeTask, withdrawTokens, loading: loading || authLoading, fetchMiningData }}>
      {children}
    </MiningContext.Provider>
  );
};

export const useMining = () => useContext(MiningContext);