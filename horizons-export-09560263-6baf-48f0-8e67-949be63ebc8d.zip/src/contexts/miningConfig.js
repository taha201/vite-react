export const PLANS = {
  free: { name: "مجاني", rate: 0.01, price: 0, claimInterval: 1 * 60 * 60 * 1000 }, // 1 hour
  weekly: { name: "أسبوعي", rate: 0.05, price: 50, claimInterval: 1 * 60 * 60 * 1000 }, 
  monthly: { name: "شهري", rate: 0.15, price: 150, claimInterval: 30 * 60 * 1000 }, // 30 mins
  yearly: { name: "سنوي", rate: 0.5, price: 1500, claimInterval: 15 * 60 * 1000 }, // 15 mins
  vip_turbomax: { name: "VIP TurboMax", rate: 2.0, price: 5000, claimInterval: 0 }, // Instant claim
};

export const FREE_CLAIM_AMOUNT = 0.5; 
export const REFERRAL_BONUS = 10; // Bonus for new user if referred
export const REFERRER_BONUS = 5; // Bonus for the referrer

export const INITIAL_MINING_DATA = {
  balance: 0,
  mining_rate: PLANS.free.rate, // Supabase uses snake_case
  last_claim_time: 0,
  next_claim_time: 0,
  can_claim: true,
  current_plan_id: 'free',
  referrals: 0,
  total_referral_earnings: 0,
  tasks_completed: {}, // Stored as JSONB
  accumulated_since_last_claim: 0,
  // These are not stored in DB, but used in frontend logic
  freeClaimAmount: FREE_CLAIM_AMOUNT,
  referralBonus: REFERRAL_BONUS, 
  minWithdrawalAmount: 10, 
  withdrawalsEnabled: true, 
};