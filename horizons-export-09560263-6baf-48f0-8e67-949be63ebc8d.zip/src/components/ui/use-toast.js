import React from 'react';

let toasts = [];

const listeners = [];

export const toast = (props) => {
  const id = Math.random().toString(36).substr(2, 9);
  const newToast = { ...props, id, open: true };
  
  toasts = [newToast, ...toasts.slice(0, 0)]; 

  listeners.forEach((listener) => listener(toasts));

  return {
    id: newToast.id,
    dismiss: () => {
      toasts = toasts.map(t => t.id === newToast.id ? { ...t, open: false } : t);
      listeners.forEach((listener) => listener(toasts));
      
      setTimeout(() => {
        toasts = toasts.filter(t => t.id !== newToast.id);
        listeners.forEach((listener) => listener(toasts));
      }, 1000);
    },
    update: (updatedProps) => {
      toasts = toasts.map(t => t.id === newToast.id ? { ...t, ...updatedProps } : t);
      listeners.forEach((listener) => listener(toasts));
    }
  };
};

export function useToast() {
  const [state, setState] = React.useState(toasts);

  React.useEffect(() => {
    const listener = (newToasts) => {
      setState([...newToasts]);
    };
    listeners.push(listener);
    return () => {
      const index = listeners.indexOf(listener);
      if (index > -1) {
        listeners.splice(index, 1);
      }
    };
  }, []);

  return {
    toasts: state,
    toast, 
  };
}