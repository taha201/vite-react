import React from 'react';
import { motion } from 'framer-motion';

const StatCard = ({ icon: Icon, title, value, color, size = "default" }) => (
  <motion.div
    whileHover={{ y: -5, boxShadow: "0px 10px 20px rgba(0,0,0,0.2)" }}
    className="bg-gray-800/60 border border-gray-700/50 rounded-lg p-4 sm:p-6 shadow-md hover:border-purple-500/50 transition-all"
  >
    <div className="flex items-center space-x-3 rtl:space-x-reverse mb-2 sm:mb-3">
      <Icon className={`h-7 w-7 sm:h-8 sm:w-8 ${color}`} />
      <h3 className={`text-sm sm:text-md font-medium text-gray-300 ${size === 'small' ? 'text-xs sm:text-sm' : ''}`}>{title}</h3>
    </div>
    <p className={`font-semibold ${color} break-all ${size === 'small' ? 'text-xl sm:text-2xl' : 'text-2xl sm:text-3xl'}`}>{value}</p>
  </motion.div>
);

export default StatCard;