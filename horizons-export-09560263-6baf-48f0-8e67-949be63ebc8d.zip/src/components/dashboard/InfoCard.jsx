import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { ExternalLink } from 'lucide-react';

const InfoCard = ({ title, description, icon: Icon, link, linkText }) => (
 <Card className="bg-gray-800/50 border-purple-500/30 h-full flex flex-col shadow-lg hover:shadow-purple-500/20 transition-shadow">
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <CardTitle className="text-md sm:text-lg font-medium text-gray-100">{title}</CardTitle>
      <Icon className="h-5 w-5 sm:h-6 sm:w-6 text-purple-400" />
    </CardHeader>
    <CardContent className="flex-grow">
      <p className="text-xs sm:text-sm text-gray-400 mb-3 sm:mb-4">{description}</p>
    </CardContent>
    {link && (
      <div className="p-3 sm:p-4 pt-0">
        <Link to={link}>
          <Button variant="outline" size="sm" className="w-full border-purple-500 text-purple-400 hover:bg-purple-500/10 hover:text-purple-300 text-xs sm:text-sm" disabled={linkText.includes("قريبًا")}>
            {linkText} <ExternalLink className="ml-1 rtl:mr-1 h-3 w-3 sm:h-4 sm:w-4" />
          </Button>
        </Link>
      </div>
    )}
  </Card>
);

export default InfoCard;