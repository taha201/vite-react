import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2 } from 'lucide-react';

const WithdrawDialog = ({ 
  isOpen, 
  onOpenChange, 
  withdrawAmount, 
  setWithdrawAmount, 
  withdrawAddress, 
  setWithdrawAddress, 
  withdrawNetwork, 
  setWithdrawNetwork, 
  handleWithdraw, 
  minWithdrawalAmount, 
  isLoading 
}) => (
  <Dialog open={isOpen} onOpenChange={onOpenChange}>
    <DialogContent className="sm:max-w-md bg-gray-800/90 backdrop-blur-md border-purple-500 text-gray-100 rounded-lg">
      <DialogHeader>
        <DialogTitle className="text-purple-300 text-lg">سحب رصيد MEMZ</DialogTitle>
        <DialogDescription className="text-gray-400 text-xs">
          الحد الأدنى للسحب: {minWithdrawalAmount} MEMZ.
        </DialogDescription>
      </DialogHeader>
      <div className="grid gap-3 py-3">
        <div className="grid grid-cols-4 items-center gap-3">
          <Label htmlFor="withdraw-amount" className="text-right rtl:text-left col-span-1 text-gray-300 text-xs">المبلغ</Label>
          <Input id="withdraw-amount" type="number" value={withdrawAmount} onChange={(e) => setWithdrawAmount(e.target.value)} placeholder="100" className="col-span-3 bg-gray-700/80 border-gray-600 text-gray-100 text-xs rounded-md h-9" />
        </div>
        <div className="grid grid-cols-4 items-center gap-3">
          <Label htmlFor="withdraw-address" className="text-right rtl:text-left col-span-1 text-gray-300 text-xs">العنوان</Label>
          <Input id="withdraw-address" value={withdrawAddress} onChange={(e) => setWithdrawAddress(e.target.value)} placeholder="عنوان محفظتك" className="col-span-3 bg-gray-700/80 border-gray-600 text-gray-100 text-xs rounded-md h-9" />
        </div>
        <div className="grid grid-cols-4 items-center gap-3">
          <Label htmlFor="withdraw-network" className="text-right rtl:text-left col-span-1 text-gray-300 text-xs">الشبكة</Label>
          <Select value={withdrawNetwork} onValueChange={setWithdrawNetwork}>
              <SelectTrigger className="col-span-3 bg-gray-700/80 border-gray-600 text-gray-100 text-xs rounded-md h-9">
                  <SelectValue placeholder="اختر الشبكة" />
              </SelectTrigger>
              <SelectContent className="bg-gray-700 border-gray-600 text-gray-100 text-xs">
                  <SelectItem value="Solana" className="hover:bg-purple-500/20 text-xs">Solana</SelectItem>
                  <SelectItem value="Bitcoin" className="hover:bg-purple-500/20 text-xs">Bitcoin</SelectItem>
                  <SelectItem value="Ethereum" className="hover:bg-purple-500/20 text-xs">Ethereum (ERC20)</SelectItem>
                  <SelectItem value="BSC" className="hover:bg-purple-500/20 text-xs">Binance Smart Chain (BEP20)</SelectItem>
              </SelectContent>
          </Select>
        </div>
      </div>
      <DialogFooter>
        <Button onClick={handleWithdraw} className="bg-gradient-to-r from-red-500 to-pink-600 text-white text-xs h-9 px-3" disabled={isLoading}>
          {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : "تأكيد السحب"}
        </Button>
        <DialogClose asChild><Button variant="ghost" className="text-xs h-9 px-3" disabled={isLoading}>إلغاء</Button></DialogClose>
      </DialogFooter>
    </DialogContent>
  </Dialog>
);

export default WithdrawDialog;