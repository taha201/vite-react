import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Trophy, Loader2 } from 'lucide-react';

const LeaderboardItem = ({ rank, name, amount }) => (
  <li className="flex justify-between items-center p-2 sm:p-3 bg-gray-700/40 rounded-md hover:bg-gray-600/60 transition-colors">
    <div className="flex items-center">
      <span className={`mr-2 sm:mr-3 font-bold w-5 sm:w-6 text-center text-xs sm:text-sm ${rank === 1 ? 'text-yellow-400' : rank === 2 ? 'text-gray-300' : rank === 3 ? 'text-orange-400' : 'text-purple-300'}`}>{rank}</span>
      <span className="text-gray-200 text-xs sm:text-sm">{name}</span>
    </div>
    <span className="font-semibold text-yellow-400 text-xs sm:text-sm">{parseFloat(amount).toFixed(2)} MEMZ</span>
  </li>
);

const LeaderboardCard = ({ leaderboardData, loading }) => (
  <Card className="bg-gray-800/70 backdrop-blur-sm border-teal-500/40 shadow-xl">
    <CardHeader>
      <CardTitle className="text-xl sm:text-2xl text-gray-100 flex items-center"><Trophy className="mr-2 h-5 w-5 sm:h-6 sm:w-6 text-yellow-300"/> لوحة شرف المعدنين</CardTitle>
      <CardDescription className="text-gray-400 text-xs sm:text-sm">شاهد ترتيب أفضل المعدنين.</CardDescription>
    </CardHeader>
    <CardContent>
      {loading && <div className="flex justify-center py-4"><Loader2 className="h-8 w-8 animate-spin text-purple-500" /></div>}
      {!loading && leaderboardData.length === 0 && <p className="text-gray-400 text-center py-4 text-xs sm:text-sm">لا يوجد بيانات لعرضها.</p>}
      {!loading && leaderboardData.length > 0 && (
        <ul className="space-y-1.5 sm:space-y-2 max-h-80 sm:max-h-96 overflow-y-auto pr-1">
          {leaderboardData.map((item) => (
            <LeaderboardItem key={item.rank} rank={item.rank} name={item.name} amount={item.amount} />
          ))}
        </ul>
      )}
    </CardContent>
  </Card>
);

export default LeaderboardCard;