import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { Gift, Zap, ArrowDownCircle, ArrowUpCircle, Loader2 } from 'lucide-react';

const MiningWalletCard = ({ miningData, onClaim, onWithdrawOpen, loading }) => (
  <Card className="lg:col-span-2 bg-gray-800/70 backdrop-blur-sm border-purple-500/40 shadow-xl">
    <CardHeader>
      <CardTitle className="text-xl sm:text-2xl text-gray-100">عمليات التعدين والمحفظة</CardTitle>
      <CardDescription className="text-gray-400 text-xs sm:text-sm">تحكم في تعدينك، طالب بمكافآتك، وقم بإدارة أموالك.</CardDescription>
    </CardHeader>
    <CardContent className="space-y-4 sm:space-y-6">
      <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
        <Button 
          onClick={onClaim} 
          disabled={!miningData.can_claim || loading}
          className="flex-1 bg-gradient-to-r from-green-500 to-teal-600 hover:from-green-600 hover:to-teal-700 text-white py-2.5 sm:py-3 text-sm sm:text-lg disabled:opacity-60 disabled:cursor-not-allowed shadow-md hover:shadow-lg transition-all"
          size="lg"
        >
          {loading ? <Loader2 className="mr-2 h-5 w-5 animate-spin"/> : <Gift className="mr-2 h-4 w-4 sm:h-5 sm:w-5" />}
           طالب بالتوكن ({miningData.freeClaimAmount} MEMZ)
        </Button>
        <Link to="/mining-plans" className="flex-1">
          <Button 
            variant="outline"
            className="w-full border-purple-500 text-purple-300 hover:bg-purple-500/25 hover:text-purple-200 py-2.5 sm:py-3 text-sm sm:text-lg shadow-md hover:shadow-lg transition-all"
            size="lg"
            disabled={loading}
          >
            <Zap className="mr-2 h-4 w-4 sm:h-5 sm:w-5" /> ترقية باقة التعدين
          </Button>
        </Link>
      </div>
      <div className="p-3 sm:p-4 bg-gray-900/70 rounded-lg text-center shadow-inner">
        <p className="text-xs sm:text-sm text-gray-400">يتم تعدين <span className="font-bold text-yellow-400">{(miningData.mining_rate / 3600).toFixed(18)} MEMZ</span> كل ثانية.</p>
        <p className="text-xxs sm:text-xs text-gray-500 mt-1">الرصيد المجمع: <span className="font-bold text-green-400">{miningData.accumulated_since_last_claim.toFixed(18)} MEMZ</span></p>
      </div>
      <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 pt-3 sm:pt-4 border-t border-gray-700/60">
        <Button onClick={onWithdrawOpen} variant="outline" className="flex-1 border-red-500/70 text-red-400 hover:bg-red-500/25 hover:text-red-300 py-2.5 sm:py-3 text-sm sm:text-lg shadow-md" disabled={!miningData.withdrawalsEnabled || loading}>
          <ArrowDownCircle className="mr-2 h-4 w-4 sm:h-5 sm:w-5" /> سحب الرصيد
        </Button>
        <Button variant="outline" className="flex-1 border-green-500/70 text-green-400 hover:bg-green-500/25 hover:text-green-300 py-2.5 sm:py-3 text-sm sm:text-lg shadow-md" disabled>
          <ArrowUpCircle className="mr-2 h-4 w-4 sm:h-5 sm:w-5" /> إيداع (قريبًا)
        </Button>
      </div>
      {!miningData.withdrawalsEnabled && <p className="text-xs text-center text-red-400 mt-2">عمليات السحب معطلة حاليًا.</p>}
    </CardContent>
  </Card>
);

export default MiningWalletCard;