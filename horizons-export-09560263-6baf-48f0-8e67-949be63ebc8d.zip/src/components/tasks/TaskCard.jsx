import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, ExternalLink, Loader2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';

const TaskCard = ({ task, onComplete, completed, loadingTask }) => {
  const { toast } = useToast();
  const [isCompleting, setIsCompleting] = useState(false);

  const handleAction = async () => {
    if (task.type === 'external_link') {
      window.open(task.actionLink, '_blank');
      if (task.duration) {
        setIsCompleting(true);
        toast({
          title: `مهمة "${task.title}"`,
          description: `يرجى البقاء في الصفحة المفتوحة لمدة ${task.duration / 1000} ثانية لإكمال المهمة.`,
          duration: task.duration + 1000,
        });
        setTimeout(() => {
          onComplete(task.id, task.reward);
          setIsCompleting(false);
        }, task.duration);
      } else {
        onComplete(task.id, task.reward);
      }
    }
  };

  const Icon = task.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card className={`bg-gray-800/60 border-gray-700/50 hover:border-purple-500/70 transition-all duration-300 ${completed ? 'opacity-60 border-green-500/50' : ''}`}>
        <CardHeader className="flex flex-row items-start space-x-4 rtl:space-x-reverse">
          <div className="p-3 bg-purple-500/20 rounded-lg">
            <Icon className="h-8 w-8 text-purple-400" />
          </div>
          <div>
            <CardTitle className="text-xl text-gray-100">{task.title}</CardTitle>
            <CardDescription className="text-gray-400 mt-1">{task.description}</CardDescription>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-yellow-400">المكافأة: {task.reward} MEMZ</p>
        </CardContent>
        <CardFooter>
          {completed ? (
            <Button variant="ghost" disabled className="w-full text-green-400">
              <CheckCircle className="mr-2 h-5 w-5" /> مكتملة
            </Button>
          ) : (
            <Button 
              onClick={handleAction} 
              disabled={loadingTask === task.id || isCompleting} 
              className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white"
            >
              {(loadingTask === task.id || isCompleting) && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {task.actionText || 'إكمال المهمة'}
              {task.type === 'external_link' && <ExternalLink className="ml-2 h-4 w-4 rtl:mr-2 rtl:ml-0" />}
            </Button>
          )}
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default TaskCard;