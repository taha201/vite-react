import React from 'react';
import { Github, Twitter, Linkedin } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className="bg-black/50 backdrop-blur-md text-gray-400 py-8 border-t border-gray-700">
      <div className="container mx-auto px-4 text-center">
        <div className="mb-4">
          <p className="text-2xl font-bold memezak-gradient-text">MEMEZAK</p>
          <p className="text-sm">منصة تعدين عملة المستقبل الرقمية</p>
        </div>
        <div className="flex justify-center space-x-6 mb-4">
          <a href="#" className="hover:text-purple-400 transition-colors"><Github size={20} /></a>
          <a href="#" className="hover:text-purple-400 transition-colors"><Twitter size={20} /></a>
          <a href="#" className="hover:text-purple-400 transition-colors"><Linkedin size={20} /></a>
        </div>
        <p className="text-xs">
          &copy; {currentYear} MEMEZAK Platform. جميع الحقوق محفوظة.
        </p>
        <p className="text-xs mt-1">
          تذكر: جميع عمليات "التعدين" على هذه المنصة هي محاكاة لأغراض العرض التوضيحي.
        </p>
         <div className="mt-2 text-xs">
          <p>عنوان عملة MEMEZAK (Solana): <code className="bg-gray-700 p-1 rounded">6aguJVbx66tjsYV2Kd6rv9jmNq2PCK8JwCV9vZqHpump</code></p>
          <p>عنوان عقد التداول: <code className="bg-gray-700 p-1 rounded">DkC3FSYYY7LLDgHZweFvSm9dWADmifHwVaNnartAXCo5</code></p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;