import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Coins, LayoutDashboard, LogIn, LogOut, User, Gem, Gamepad2, ListChecks } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { motion } from 'framer-motion';

const Navbar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/auth');
  };

  return (
    <motion.nav 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5, type: 'spring', stiffness: 120 }}
      className="bg-black/30 backdrop-blur-lg shadow-lg sticky top-0 z-50"
    >
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <Link to="/" className="text-3xl font-bold memezak-gradient-text tracking-tighter">
          MEMEZAK
        </Link>
        <div className="space-x-1 md:space-x-2 flex items-center">
          <NavLink to="/"><LayoutDashboard className="mr-1 h-4 w-4 inline"/>الرئيسية</NavLink>
          {user && <NavLink to="/dashboard"><Coins className="mr-1 h-4 w-4 inline"/>لوحة التحكم</NavLink>}
          {user && <NavLink to="/mining-plans"><Gem className="mr-1 h-4 w-4 inline"/>الباقات</NavLink>}
          {user && <NavLink to="/tasks"><ListChecks className="mr-1 h-4 w-4 inline"/>المهام</NavLink>}
          {user && <NavLink to="/game"><Gamepad2 className="mr-1 h-4 w-4 inline"/>SuperMEMEZAK</NavLink>}
          
          {user ? (
            <>
              <NavLink to="/profile"><User className="mr-1 h-4 w-4 inline"/>{user.username}</NavLink>
              <Button variant="ghost" onClick={handleLogout} className="text-red-400 hover:text-red-500 hover:bg-red-900/50 px-2 py-1 md:px-3 md:py-2">
                <LogOut className="mr-1 md:mr-2 h-4 w-4 md:h-5 md:w-5" /> <span className="hidden sm:inline">خروج</span>
              </Button>
            </>
          ) : (
            <Button onClick={() => navigate('/auth')} variant="ghost" className="text-purple-400 hover:text-purple-300 hover:bg-purple-900/50 px-2 py-1 md:px-3 md:py-2">
              <LogIn className="mr-1 md:mr-2 h-4 w-4 md:h-5 md:w-5" /> <span className="hidden sm:inline">دخول</span>
            </Button>
          )}
        </div>
      </div>
    </motion.nav>
  );
};

const NavLink = ({ to, children }) => (
  <Link
    to={to}
    className="text-xs sm:text-sm font-medium text-gray-300 hover:text-white transition-colors px-2 py-1 md:px-3 md:py-2 rounded-md hover:bg-white/10 flex items-center"
  >
    {children}
  </Link>
);

export default Navbar;